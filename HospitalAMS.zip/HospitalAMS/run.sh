#!/bin/bash
# ============================================================
#  Hospital AMS — Build & Run Script (No Maven)
#  Requires: JDK 11+, MySQL connector JAR in lib/
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

LIB="$SCRIPT_DIR/lib"
SRC="$SCRIPT_DIR/src"
OUT="$SCRIPT_DIR/out"

# Check for MySQL connector
JAR=$(ls "$LIB"/mysql-connector-*.jar 2>/dev/null | head -1)
if [ -z "$JAR" ]; then
  echo "ERROR: MySQL JDBC connector JAR not found in lib/"
  echo "Download from: https://dev.mysql.com/downloads/connector/j/"
  echo "Place mysql-connector-j-*.jar in the lib/ folder."
  exit 1
fi

echo "Using JAR: $JAR"
mkdir -p "$OUT"

# Compile all Java sources
echo "Compiling..."
find "$SRC" -name "*.java" | xargs javac \
  -cp "$JAR" \
  -d "$OUT" \
  -sourcepath "$SRC" \
  2>&1

if [ $? -ne 0 ]; then
  echo "Compilation FAILED."
  exit 1
fi

echo "Compilation successful. Starting server..."
cd "$SCRIPT_DIR"
java -cp "$OUT:$JAR" HospitalServer
