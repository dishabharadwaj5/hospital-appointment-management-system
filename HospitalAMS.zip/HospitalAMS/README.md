# 🏥 MediCare AMS — Hospital Appointment Management System

> Pure Java (no Maven/Spring) + MySQL + Beautiful HTML/CSS/JS Frontend

---

## 📁 Project Structure

```
HospitalAMS/
├── src/
│   ├── HospitalServer.java          ← Main HTTP server (entry point)
│   ├── util/
│   │   ├── DBConnection.java        ← Singleton DB connection
│   │   └── JsonUtil.java            ← Lightweight JSON builder
│   ├── model/
│   │   ├── User.java
│   │   ├── Doctor.java
│   │   ├── Patient.java
│   │   ├── Appointment.java
│   │   └── Schedule.java
│   ├── dao/
│   │   ├── UserDAO.java
│   │   ├── DoctorDAO.java
│   │   ├── PatientDAO.java
│   │   ├── ScheduleDAO.java
│   │   └── AppointmentDAO.java
│   ├── factory/
│   │   └── UserFactory.java         ← Creational: Factory pattern
│   ├── observer/
│   │   ├── AppointmentObserver.java ← Behavioral: Observer interface
│   │   ├── AppointmentEventManager.java
│   │   └── AuditLogObserver.java
│   ├── adapter/
│   │   ├── ReportFormatter.java     ← Structural: Adapter pattern
│   │   ├── RawCsvGenerator.java
│   │   ├── CsvReportAdapter.java
│   │   └── TextReportFormatter.java
│   └── strategy/
│       └── FilterStrategy.java      ← Additional: Strategy pattern
├── frontend/
│   └── index.html                   ← Full SPA frontend
├── lib/
│   └── mysql-connector-j-*.jar      ← YOU MUST PLACE THIS HERE
├── sql/
│   └── schema.sql                   ← Database setup script
├── run.sh                           ← Linux/Mac startup script
├── run.bat                          ← Windows startup script
└── README.md
```

---

## 🎨 Design Patterns Used

| Pattern | Type | Location | Purpose |
|---------|------|----------|---------|
| **Factory** | Creational | `factory/UserFactory.java` | Creates User objects by role |
| **Adapter** | Structural | `adapter/CsvReportAdapter.java` | Adapts raw CSV generator to unified interface |
| **Observer** | Behavioral | `observer/` package | Notifies audit log on appointment events |
| **Strategy** | Additional | `strategy/FilterStrategy.java` | Swappable appointment filter algorithms |
| **Singleton** | Creational | `util/DBConnection.java` | Single shared DB connection |

---

## 🚀 Setup & Run Instructions

### Step 1 — Prerequisites
- **Java JDK 11+** → https://adoptium.net/
- **MySQL 8.0+** → https://dev.mysql.com/downloads/mysql/
- **MySQL JDBC Connector JAR** → https://dev.mysql.com/downloads/connector/j/

### Step 2 — Database Setup

1. Open MySQL Workbench or MySQL CLI
2. Run the schema file:

```sql
source /path/to/HospitalAMS/sql/schema.sql
```

Or paste and execute the contents of `sql/schema.sql`.

### Step 3 — Add MySQL JDBC Driver

1. Download `mysql-connector-j-*.jar` from MySQL website
2. Place the JAR file inside the `lib/` folder:
   ```
   HospitalAMS/lib/mysql-connector-j-8.x.x.jar
   ```

### Step 4 — Update Database Credentials

Edit `src/util/DBConnection.java`:
```java
private static final String URL      = "jdbc:mysql://localhost:3306/hospital_ams?...";
private static final String USER     = "root";        // ← your MySQL username
private static final String PASSWORD = "root";        // ← your MySQL password
```

### Step 5 — Compile & Run

**Linux / Mac:**
```bash
chmod +x run.sh
./run.sh
```

**Windows:**
```
Double-click run.bat
```

Or manually:
```bash
# Create output dir
mkdir out

# Compile all sources
find src -name "*.java" | xargs javac -cp lib/mysql-connector-j-*.jar -d out -sourcepath src

# Run server
java -cp "out:lib/mysql-connector-j-*.jar" HospitalServer
```

### Step 6 — Open in Browser

```
http://localhost:8080
```

---

## 🔐 Default Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Doctor | `dr.sharma` | `doc123` |
| Doctor | `dr.priya` | `doc123` |
| Doctor | `dr.mehta` | `doc123` |
| Patient | `patient1` | `pat123` |

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/login` | Authenticate user |
| GET | `/api/doctors` | List all doctors |
| POST | `/api/doctors` | Add doctor |
| DELETE | `/api/doctors/{id}` | Delete doctor |
| GET | `/api/patients` | List all patients |
| POST | `/api/patients` | Register patient |
| DELETE | `/api/patients/{id}` | Delete patient |
| GET | `/api/schedules?doctorId=&date=` | Get slots |
| POST | `/api/schedules` | Add slot |
| GET | `/api/appointments` | All appointments |
| POST | `/api/appointments` | Book appointment |
| PUT | `/api/appointments/{id}/status` | Update status |
| GET | `/api/appointments/date?date=` | Filter by date |
| GET | `/api/appointments/patient/{id}` | Patient's appointments |
| GET | `/api/appointments/doctor/{id}` | Doctor's appointments |
| GET | `/api/summary?date=` | Daily summary |
| GET | `/api/doctor-stats` | Doctor-wise stats |
| GET | `/api/report?format=csv\|txt` | Download report |

---

## ✅ Features Checklist

- [x] Role-based access (Admin, Doctor, Patient)
- [x] Doctor & Patient management (CRUD)
- [x] Appointment booking with slot selection
- [x] ⚠️ Overbooking warning — "No slots available"
- [x] Daily appointment summary strip
- [x] Doctor-wise appointment count (bar chart)
- [x] Date-wise appointment history
- [x] Search and filter (patient name, doctor name, ID, status)
- [x] Total slots managed counter
- [x] Report download (CSV and TXT)
- [x] Appointment status tracking (BOOKED → COMPLETED/CANCELLED)
- [x] Automatic slot release on cancellation
- [x] Observer pattern audit logging
- [x] MVC architecture
- [x] SOLID principles applied
- [x] 4 design patterns (Factory, Adapter, Observer, Strategy + Singleton)

---

## 🏗 Architecture

```
Frontend (HTML/CSS/JS)
        ↓ HTTP/JSON
HospitalServer.java (HTTP handlers = Controller layer)
        ↓
DAO layer (Model + Data Access)
        ↓
MySQL Database
```

The server uses Java's built-in `com.sun.net.httpserver.HttpServer` — **no external frameworks needed**.
