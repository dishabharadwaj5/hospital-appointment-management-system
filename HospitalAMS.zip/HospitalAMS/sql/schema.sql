-- Hospital Appointment Management System - Database Schema
-- Run this file in MySQL before starting the application

CREATE DATABASE IF NOT EXISTS hospital_ams;
USE hospital_ams;

-- Users table (base for Admin, Doctor, Patient)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('ADMIN','DOCTOR','PATIENT') NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Doctors table
CREATE TABLE IF NOT EXISTS doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    qualification VARCHAR(100),
    total_slots INT DEFAULT 10,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    age INT,
    gender ENUM('Male','Female','Other'),
    address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Schedules table (available time slots per doctor per date)
CREATE TABLE IF NOT EXISTS schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT NOT NULL,
    slot_date DATE NOT NULL,
    slot_time VARCHAR(20) NOT NULL,
    is_booked BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    schedule_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time VARCHAR(20) NOT NULL,
    status ENUM('BOOKED','COMPLETED','CANCELLED') DEFAULT 'BOOKED',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(id),
    FOREIGN KEY (schedule_id) REFERENCES schedules(id)
);

-- Seed Admin
INSERT IGNORE INTO users (username, password, role, full_name, email, phone)
VALUES ('admin', 'admin123', 'ADMIN', 'System Administrator', 'admin@hospital.com', '9999999999');

-- Seed Sample Doctors
INSERT IGNORE INTO users (username, password, role, full_name, email, phone) VALUES
('dr.sharma', 'doc123', 'DOCTOR', 'Dr. Rajesh Sharma', 'sharma@hospital.com', '9876543210'),
('dr.priya', 'doc123', 'DOCTOR', 'Dr. Priya Nair', 'priya@hospital.com', '9876543211'),
('dr.mehta', 'doc123', 'DOCTOR', 'Dr. Anil Mehta', 'mehta@hospital.com', '9876543212'),
('dr.kavya', 'doc123', 'DOCTOR', 'Dr. Kavya Reddy', 'kavya@hospital.com', '9876543213');

INSERT IGNORE INTO doctors (user_id, specialization, qualification, total_slots)
SELECT id, 'Cardiology', 'MBBS, MD', 10 FROM users WHERE username='dr.sharma';
INSERT IGNORE INTO doctors (user_id, specialization, qualification, total_slots)
SELECT id, 'Neurology', 'MBBS, DM', 8 FROM users WHERE username='dr.priya';
INSERT IGNORE INTO doctors (user_id, specialization, qualification, total_slots)
SELECT id, 'Orthopedics', 'MBBS, MS', 12 FROM users WHERE username='dr.mehta';
INSERT IGNORE INTO doctors (user_id, specialization, qualification, total_slots)
SELECT id, 'Dermatology', 'MBBS, DVD', 10 FROM users WHERE username='dr.kavya';

-- Seed Sample Patient
INSERT IGNORE INTO users (username, password, role, full_name, email, phone)
VALUES ('patient1', 'pat123', 'PATIENT', 'Arjun Kumar', 'arjun@mail.com', '8888888888');

INSERT IGNORE INTO patients (user_id, age, gender, address)
SELECT id, 32, 'Male', 'Bengaluru, Karnataka' FROM users WHERE username='patient1';

-- Seed sample schedules for today and next 7 days
DELIMITER $$
CREATE PROCEDURE IF NOT EXISTS seed_schedules()
BEGIN
  DECLARE i INT DEFAULT 0;
  DECLARE j INT DEFAULT 0;
  DECLARE d INT;
  DECLARE slot_t VARCHAR(20);
  DECLARE slots VARCHAR(200);
  
  WHILE i < 7 DO
    SET j = 1;
    WHILE j <= 4 DO
      -- For each doctor (id 1-4)
      FOREACH_DOCTOR: BEGIN
        DECLARE doc_id INT DEFAULT 1;
        WHILE doc_id <= 4 DO
          SET slot_t = CASE j
            WHEN 1 THEN '09:00 AM'
            WHEN 2 THEN '11:00 AM'
            WHEN 3 THEN '02:00 PM'
            WHEN 4 THEN '04:00 PM'
          END;
          INSERT IGNORE INTO schedules (doctor_id, slot_date, slot_time, is_booked)
          VALUES (doc_id, DATE_ADD(CURDATE(), INTERVAL i DAY), slot_t, FALSE);
          SET doc_id = doc_id + 1;
        END WHILE;
      END FOREACH_DOCTOR;
      SET j = j + 1;
    END WHILE;
    SET i = i + 1;
  END WHILE;
END$$
DELIMITER ;

-- Simpler schedule seeding without stored procedure complexity:
INSERT IGNORE INTO schedules (doctor_id, slot_date, slot_time, is_booked)
SELECT d.id, DATE_ADD(CURDATE(), INTERVAL n.n DAY), t.slot_time, FALSE
FROM doctors d
CROSS JOIN (SELECT 0 AS n UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6) n
CROSS JOIN (SELECT '09:00 AM' AS slot_time UNION SELECT '11:00 AM' UNION SELECT '02:00 PM' UNION SELECT '04:00 PM') t;

SELECT 'Database setup complete!' AS Status;
