@echo off
:: ============================================================
::  Hospital AMS — Build & Run Script for Windows (No Maven)
:: ============================================================
cd /d "%~dp0"

set LIB=%~dp0lib
set SRC=%~dp0src
set OUT=%~dp0out

:: Find MySQL JAR
for %%f in ("%LIB%\mysql-connector-*.jar") do set JAR=%%f
if "%JAR%"=="" (
    echo ERROR: MySQL JDBC connector JAR not found in lib\
    echo Download from: https://dev.mysql.com/downloads/connector/j/
    echo Place mysql-connector-j-*.jar in the lib\ folder.
    pause
    exit /b 1
)

echo Using JAR: %JAR%
if not exist "%OUT%" mkdir "%OUT%"

:: Collect all .java files
echo Compiling...
dir /s /b "%SRC%\*.java" > sources.txt
javac -cp "%JAR%" -d "%OUT%" -sourcepath "%SRC%" @sources.txt
del sources.txt

if %ERRORLEVEL% neq 0 (
    echo Compilation FAILED.
    pause
    exit /b 1
)

echo Compilation successful. Starting server...
java -cp "%OUT%;%JAR%" HospitalServer
pause
