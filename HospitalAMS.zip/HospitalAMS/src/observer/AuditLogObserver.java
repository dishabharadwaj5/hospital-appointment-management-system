package observer;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Concrete Observer: logs appointment events to console.
 */
public class AuditLogObserver implements AppointmentObserver {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public void onAppointmentEvent(String eventType, int appointmentId, String details) {
        String timestamp = LocalDateTime.now().format(FMT);
        System.out.println("[AUDIT " + timestamp + "] Event=" + eventType
                + " | AppointmentID=" + appointmentId + " | Info=" + details);
    }
}
