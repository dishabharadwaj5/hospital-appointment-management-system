package observer;

/**
 * BEHAVIORAL PATTERN: Observer
 * Observers are notified when an appointment event occurs (booked/cancelled/completed).
 */
public interface AppointmentObserver {
    void onAppointmentEvent(String eventType, int appointmentId, String details);
}
