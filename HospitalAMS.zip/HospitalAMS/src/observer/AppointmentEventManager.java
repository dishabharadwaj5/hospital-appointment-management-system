package observer;

import java.util.ArrayList;
import java.util.List;

/**
 * Subject/Publisher in Observer pattern.
 * Manages observer registration and notification.
 */
public class AppointmentEventManager {
    private static AppointmentEventManager instance;
    private final List<AppointmentObserver> observers = new ArrayList<>();

    private AppointmentEventManager() {}

    public static AppointmentEventManager getInstance() {
        if (instance == null) instance = new AppointmentEventManager();
        return instance;
    }

    public void subscribe(AppointmentObserver observer) {
        observers.add(observer);
    }

    public void unsubscribe(AppointmentObserver observer) {
        observers.remove(observer);
    }

    public void notify(String eventType, int appointmentId, String details) {
        System.out.println("[EVENT] " + eventType + " | Appt#" + appointmentId + " | " + details);
        for (AppointmentObserver o : observers) {
            o.onAppointmentEvent(eventType, appointmentId, details);
        }
    }
}
