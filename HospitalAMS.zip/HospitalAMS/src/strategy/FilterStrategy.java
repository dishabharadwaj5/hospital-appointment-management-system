package strategy;

import model.Appointment;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ADDITIONAL PATTERN: Strategy
 * Encapsulates appointment filtering algorithms so they can be swapped at runtime.
 */
public interface FilterStrategy {
    List<Appointment> filter(List<Appointment> appointments, String keyword);
}

class FilterByPatientName implements FilterStrategy {
    @Override
    public List<Appointment> filter(List<Appointment> appointments, String keyword) {
        String kw = keyword.toLowerCase();
        return appointments.stream()
                .filter(a -> a.getPatientName() != null && a.getPatientName().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}

class FilterByDoctorName implements FilterStrategy {
    @Override
    public List<Appointment> filter(List<Appointment> appointments, String keyword) {
        String kw = keyword.toLowerCase();
        return appointments.stream()
                .filter(a -> a.getDoctorName() != null && a.getDoctorName().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}

class FilterByAppointmentId implements FilterStrategy {
    @Override
    public List<Appointment> filter(List<Appointment> appointments, String keyword) {
        try {
            int id = Integer.parseInt(keyword.trim());
            return appointments.stream()
                    .filter(a -> a.getId() == id)
                    .collect(Collectors.toList());
        } catch (NumberFormatException e) {
            return appointments;
        }
    }
}
