import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.Headers;

import dao.*;
import model.*;
import factory.UserFactory;
import observer.*;
import adapter.*;
import util.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.Executors;

/**
 * Pure Java HTTP Server — no Maven, no Spring.
 * Uses com.sun.net.httpserver (built into JDK 6+).
 *
 * Endpoints:
 *   POST /api/login
 *   GET  /api/doctors
 *   POST /api/doctors
 *   PUT  /api/doctors/{id}
 *   DELETE /api/doctors/{id}
 *   GET  /api/patients
 *   POST /api/patients
 *   PUT  /api/patients/{id}
 *   DELETE /api/patients/{id}
 *   GET  /api/schedules?doctorId=&date=
 *   POST /api/schedules
 *   GET  /api/appointments
 *   POST /api/appointments
 *   PUT  /api/appointments/{id}/status
 *   GET  /api/appointments/date?date=
 *   GET  /api/appointments/patient/{id}
 *   GET  /api/appointments/doctor/{id}
 *   GET  /api/summary?date=
 *   GET  /api/doctor-stats
 *   GET  /api/report?format=csv|txt
 */
public class HospitalServer {

    private static final int PORT = 8080;

    // DAOs
    static final UserDAO        userDAO        = new UserDAO();
    static final DoctorDAO      doctorDAO      = new DoctorDAO();
    static final PatientDAO     patientDAO     = new PatientDAO();
    static final ScheduleDAO    scheduleDAO    = new ScheduleDAO();
    static final AppointmentDAO appointmentDAO = new AppointmentDAO();

    public static void main(String[] args) throws Exception {
        // Wire up Observer pattern
        AppointmentEventManager events = AppointmentEventManager.getInstance();
        events.subscribe(new AuditLogObserver());

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.setExecutor(Executors.newFixedThreadPool(10));

        // Static frontend files
        server.createContext("/", new StaticHandler());

        // API routes
        server.createContext("/api/login",        new LoginHandler());
        server.createContext("/api/doctors",       new DoctorHandler());
        server.createContext("/api/patients",      new PatientHandler());
        server.createContext("/api/schedules",     new ScheduleHandler());
        server.createContext("/api/appointments",  new AppointmentHandler());
        server.createContext("/api/summary",       new SummaryHandler());
        server.createContext("/api/doctor-stats",  new DoctorStatsHandler());
        server.createContext("/api/report",        new ReportHandler());

        server.start();
        System.out.println("====================================================");
        System.out.println("  Hospital AMS Server started on http://localhost:" + PORT);
        System.out.println("  Open your browser and navigate to that URL.");
        System.out.println("====================================================");
    }

    // ─────────────────────────── Utility ────────────────────────────

    static void sendJson(HttpExchange ex, int code, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        Headers h = ex.getResponseHeaders();
        h.set("Content-Type", "application/json; charset=UTF-8");
        h.set("Access-Control-Allow-Origin", "*");
        h.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        h.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    static String readBody(HttpExchange ex) throws IOException {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(ex.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    static Map<String, String> parseJson(String json) {
        Map<String, String> map = new LinkedHashMap<>();
        if (json == null || json.isBlank()) return map;
        json = json.trim();
        if (json.startsWith("{")) json = json.substring(1);
        if (json.endsWith("}")) json = json.substring(0, json.length() - 1);
        for (String pair : json.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)")) {
            String[] kv = pair.split(":", 2);
            if (kv.length == 2) {
                String k = kv[0].trim().replaceAll("\"", "");
                String v = kv[1].trim().replaceAll("^\"|\"$", "");
                map.put(k, v);
            }
        }
        return map;
    }

    static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new LinkedHashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String p : query.split("&")) {
            String[] kv = p.split("=", 2);
            if (kv.length == 2) {
                try { map.put(URLDecoder.decode(kv[0], "UTF-8"), URLDecoder.decode(kv[1], "UTF-8")); }
                catch (Exception e) { map.put(kv[0], kv[1]); }
            }
        }
        return map;
    }

    static boolean handleOptions(HttpExchange ex) throws IOException {
        if ("OPTIONS".equals(ex.getRequestMethod())) {
            sendJson(ex, 204, "");
            return true;
        }
        return false;
    }

    // ─────────────────────────── Static file handler ────────────────

    static class StaticHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            String path = ex.getRequestURI().getPath();
            if (path.equals("/") || path.equals("/index.html")) {
                File f = new File("frontend/index.html");
                if (!f.exists()) {
                    String msg = "Frontend not found. Place index.html in frontend/ folder.";
                    ex.sendResponseHeaders(404, msg.length());
                    ex.getResponseBody().write(msg.getBytes());
                    ex.getResponseBody().close();
                    return;
                }
                byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
                ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                ex.sendResponseHeaders(200, bytes.length);
                ex.getResponseBody().write(bytes);
                ex.getResponseBody().close();
            } else {
                ex.sendResponseHeaders(404, 0);
                ex.getResponseBody().close();
            }
        }
    }

    // ─────────────────────────── /api/login ─────────────────────────

    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            if (!"POST".equals(ex.getRequestMethod())) { sendJson(ex, 405, JsonUtil.error("Method not allowed")); return; }
            try {
                Map<String, String> body = parseJson(readBody(ex));
                String username = body.get("username");
                String password = body.get("password");
                User user = userDAO.authenticate(username, password);
                if (user == null) { sendJson(ex, 401, JsonUtil.error("Invalid credentials")); return; }

                Map<String, Object> resp = new LinkedHashMap<>();
                resp.put("success", true);
                resp.put("id", user.getId());
                resp.put("username", user.getUsername());
                resp.put("role", user.getRole());
                resp.put("fullName", user.getFullName());

                if ("DOCTOR".equals(user.getRole())) {
                    Doctor d = doctorDAO.findByUserId(user.getId());
                    if (d != null) resp.put("doctorId", d.getId());
                }
                if ("PATIENT".equals(user.getRole())) {
                    Patient p = patientDAO.findByUserId(user.getId());
                    if (p != null) resp.put("patientId", p.getId());
                }
                sendJson(ex, 200, JsonUtil.toJson(resp));
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/doctors ───────────────────────

    static class DoctorHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            String method = ex.getRequestMethod();
            String path   = ex.getRequestURI().getPath();

            try {
                if ("GET".equals(method)) {
                    List<Doctor> docs = doctorDAO.findAll();
                    List<Map<String, Object>> list = new ArrayList<>();
                    for (Doctor d : docs) {
                        Map<String, Object> m = new LinkedHashMap<>();
                        m.put("id", d.getId()); m.put("userId", d.getUserId());
                        m.put("fullName", d.getFullName()); m.put("specialization", d.getSpecialization());
                        m.put("qualification", d.getQualification()); m.put("totalSlots", d.getTotalSlots());
                        m.put("bookedSlots", d.getBookedSlots()); m.put("availableSlots", d.getAvailableSlots());
                        list.add(m);
                    }
                    sendJson(ex, 200, JsonUtil.toJson(list));

                } else if ("POST".equals(method)) {
                    Map<String, String> body = parseJson(readBody(ex));
                    // Create user first via Factory
                    User user = UserFactory.createUser("DOCTOR",
                        body.get("username"), body.get("password"),
                        body.get("fullName"), body.getOrDefault("email",""),
                        body.getOrDefault("phone",""));
                    if (userDAO.usernameExists(user.getUsername())) {
                        sendJson(ex, 409, JsonUtil.error("Username already exists")); return;
                    }
                    int userId = userDAO.insert(user);
                    int totalSlots = Integer.parseInt(body.getOrDefault("totalSlots", "10"));
                    doctorDAO.insert(userId, body.get("specialization"), body.getOrDefault("qualification","MBBS"), totalSlots);
                    sendJson(ex, 201, JsonUtil.success("Doctor added successfully"));

                } else if ("PUT".equals(method)) {
                    String[] parts = path.split("/");
                    int id = Integer.parseInt(parts[parts.length - 1]);
                    Map<String, String> body = parseJson(readBody(ex));
                    doctorDAO.update(id, body.get("specialization"),
                        body.getOrDefault("qualification", "MBBS"),
                        Integer.parseInt(body.getOrDefault("totalSlots", "10")));
                    sendJson(ex, 200, JsonUtil.success("Doctor updated"));

                } else if ("DELETE".equals(method)) {
                    String[] parts = path.split("/");
                    int id = Integer.parseInt(parts[parts.length - 1]);
                    Doctor d = doctorDAO.findById(id);
                    if (d != null) { doctorDAO.delete(id); userDAO.delete(d.getUserId()); }
                    sendJson(ex, 200, JsonUtil.success("Doctor deleted"));
                }
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/patients ──────────────────────

    static class PatientHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            String method = ex.getRequestMethod();
            String path   = ex.getRequestURI().getPath();
            try {
                if ("GET".equals(method)) {
                    List<Patient> patients = patientDAO.findAll();
                    List<Map<String, Object>> list = new ArrayList<>();
                    for (Patient p : patients) {
                        Map<String, Object> m = new LinkedHashMap<>();
                        m.put("id", p.getId()); m.put("userId", p.getUserId());
                        m.put("fullName", p.getFullName()); m.put("age", p.getAge());
                        m.put("gender", p.getGender()); m.put("address", p.getAddress());
                        m.put("email", p.getEmail()); m.put("phone", p.getPhone());
                        list.add(m);
                    }
                    sendJson(ex, 200, JsonUtil.toJson(list));

                } else if ("POST".equals(method)) {
                    Map<String, String> body = parseJson(readBody(ex));
                    User user = UserFactory.createUser("PATIENT",
                        body.get("username"), body.get("password"),
                        body.get("fullName"), body.getOrDefault("email",""),
                        body.getOrDefault("phone",""));
                    if (userDAO.usernameExists(user.getUsername())) {
                        sendJson(ex, 409, JsonUtil.error("Username already exists")); return;
                    }
                    int userId = userDAO.insert(user);
                    patientDAO.insert(userId,
                        Integer.parseInt(body.getOrDefault("age","0")),
                        body.getOrDefault("gender","Other"),
                        body.getOrDefault("address",""));
                    sendJson(ex, 201, JsonUtil.success("Patient registered successfully"));

                } else if ("PUT".equals(method)) {
                    String[] parts = path.split("/");
                    int id = Integer.parseInt(parts[parts.length - 1]);
                    Map<String, String> body = parseJson(readBody(ex));
                    patientDAO.update(id,
                        Integer.parseInt(body.getOrDefault("age","0")),
                        body.getOrDefault("gender","Other"),
                        body.getOrDefault("address",""));
                    sendJson(ex, 200, JsonUtil.success("Patient updated"));

                } else if ("DELETE".equals(method)) {
                    String[] parts = path.split("/");
                    int id = Integer.parseInt(parts[parts.length - 1]);
                    Patient p = patientDAO.findById(id);
                    if (p != null) { patientDAO.delete(id); userDAO.delete(p.getUserId()); }
                    sendJson(ex, 200, JsonUtil.success("Patient deleted"));
                }
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/schedules ─────────────────────

    static class ScheduleHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            String method = ex.getRequestMethod();
            try {
                if ("GET".equals(method)) {
                    Map<String, String> params = parseQuery(ex.getRequestURI().getQuery());
                    int doctorId = Integer.parseInt(params.getOrDefault("doctorId", "0"));
                    String date  = params.getOrDefault("date", "");
                    List<model.Schedule> slots = scheduleDAO.findByDoctorAndDate(doctorId, date);
                    List<Map<String, Object>> list = new ArrayList<>();
                    for (model.Schedule s : slots) {
                        Map<String, Object> m = new LinkedHashMap<>();
                        m.put("id", s.getId()); m.put("doctorId", s.getDoctorId());
                        m.put("slotDate", s.getSlotDate()); m.put("slotTime", s.getSlotTime());
                        m.put("isBooked", s.isBooked());
                        list.add(m);
                    }
                    sendJson(ex, 200, JsonUtil.toJson(list));

                } else if ("POST".equals(method)) {
                    Map<String, String> body = parseJson(readBody(ex));
                    int doctorId = Integer.parseInt(body.get("doctorId"));
                    String date  = body.get("date");
                    String time  = body.get("time");
                    scheduleDAO.insert(doctorId, date, time);
                    sendJson(ex, 201, JsonUtil.success("Slot added"));
                }
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/appointments ──────────────────

    static class AppointmentHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            String method = ex.getRequestMethod();
            String path   = ex.getRequestURI().getPath();
            Map<String, String> params = parseQuery(ex.getRequestURI().getQuery());

            try {
                // GET /api/appointments/date?date=YYYY-MM-DD
                if ("GET".equals(method) && path.endsWith("/date")) {
                    String date = params.getOrDefault("date", "");
                    sendJson(ex, 200, appointmentsToJson(appointmentDAO.findByDate(date)));
                    return;
                }
                // GET /api/appointments/patient/{id}
                if ("GET".equals(method) && path.contains("/patient/")) {
                    int pid = Integer.parseInt(path.substring(path.lastIndexOf('/') + 1));
                    sendJson(ex, 200, appointmentsToJson(appointmentDAO.findByPatientId(pid)));
                    return;
                }
                // GET /api/appointments/doctor/{id}
                if ("GET".equals(method) && path.contains("/doctor/")) {
                    int did = Integer.parseInt(path.substring(path.lastIndexOf('/') + 1));
                    sendJson(ex, 200, appointmentsToJson(appointmentDAO.findByDoctorId(did)));
                    return;
                }
                // PUT /api/appointments/{id}/status
                if ("PUT".equals(method) && path.contains("/status")) {
                    String[] parts = path.split("/");
                    int id = Integer.parseInt(parts[parts.length - 2]);
                    Map<String, String> body = parseJson(readBody(ex));
                    String status = body.get("status");
                    appointmentDAO.updateStatus(id, status);

                    // If cancelling, free the slot
                    if ("CANCELLED".equals(status)) {
                        Appointment a = appointmentDAO.findById(id);
                        if (a != null) scheduleDAO.markBooked(a.getScheduleId(), false);
                    }
                    AppointmentEventManager.getInstance().notify(status, id, "Status updated to " + status);
                    sendJson(ex, 200, JsonUtil.success("Status updated to " + status));
                    return;
                }

                if ("GET".equals(method)) {
                    sendJson(ex, 200, appointmentsToJson(appointmentDAO.findAll()));
                } else if ("POST".equals(method)) {
                    Map<String, String> body = parseJson(readBody(ex));
                    int doctorId   = Integer.parseInt(body.get("doctorId"));
                    int patientId  = Integer.parseInt(body.get("patientId"));
                    int scheduleId = Integer.parseInt(body.get("scheduleId"));

                    model.Schedule slot = scheduleDAO.findById(scheduleId);
                    if (slot == null || slot.isBooked()) {
                        sendJson(ex, 409, JsonUtil.error("⚠️ No slots available")); return;
                    }

                    Appointment a = new Appointment();
                    a.setPatientId(patientId); a.setDoctorId(doctorId);
                    a.setScheduleId(scheduleId);
                    a.setAppointmentDate(slot.getSlotDate());
                    a.setAppointmentTime(slot.getSlotTime());
                    a.setNotes(body.getOrDefault("notes", ""));

                    int apptId = appointmentDAO.insert(a);
                    scheduleDAO.markBooked(scheduleId, true);

                    AppointmentEventManager.getInstance().notify("BOOKED", apptId,
                        "Patient#" + patientId + " booked Doctor#" + doctorId);
                    sendJson(ex, 201, JsonUtil.success("Appointment booked! ID: " + apptId));
                }
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }

        private String appointmentsToJson(List<Appointment> list) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Appointment a : list) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("id", a.getId()); m.put("patientId", a.getPatientId());
                m.put("doctorId", a.getDoctorId()); m.put("scheduleId", a.getScheduleId());
                m.put("appointmentDate", a.getAppointmentDate());
                m.put("appointmentTime", a.getAppointmentTime());
                m.put("status", a.getStatus()); m.put("notes", a.getNotes());
                m.put("patientName", a.getPatientName()); m.put("doctorName", a.getDoctorName());
                m.put("specialization", a.getSpecialization());
                result.add(m);
            }
            return JsonUtil.toJson(result);
        }
    }

    // ─────────────────────────── /api/summary ───────────────────────

    static class SummaryHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            try {
                Map<String, String> params = parseQuery(ex.getRequestURI().getQuery());
                String date = params.getOrDefault("date", java.time.LocalDate.now().toString());
                Map<String, Object> summary = appointmentDAO.getDailySummary(date);
                sendJson(ex, 200, JsonUtil.toJson(summary));
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/doctor-stats ──────────────────

    static class DoctorStatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            try {
                List<Map<String, Object>> stats = doctorDAO.getDoctorAppointmentCounts();
                sendJson(ex, 200, JsonUtil.toJson(stats));
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }

    // ─────────────────────────── /api/report ────────────────────────

    static class ReportHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if (handleOptions(ex)) return;
            try {
                Map<String, String> params = parseQuery(ex.getRequestURI().getQuery());
                String format = params.getOrDefault("format", "csv");

                // ADAPTER PATTERN in action
                ReportFormatter formatter = "txt".equalsIgnoreCase(format)
                        ? new TextReportFormatter()
                        : new CsvReportAdapter();

                List<Map<String, Object>> data = appointmentDAO.getReportData();
                String content = formatter.format(data);
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);

                Headers h = ex.getResponseHeaders();
                h.set("Content-Type", formatter.getContentType());
                h.set("Content-Disposition",
                    "attachment; filename=\"appointments_report." + formatter.getFileExtension() + "\"");
                h.set("Access-Control-Allow-Origin", "*");
                ex.sendResponseHeaders(200, bytes.length);
                try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
            } catch (Exception e) {
                sendJson(ex, 500, JsonUtil.error(e.getMessage()));
            }
        }
    }
}
