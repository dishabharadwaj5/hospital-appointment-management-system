package dao;

import model.Schedule;
import util.DBConnection;

import java.sql.*;
import java.util.*;

public class ScheduleDAO {
    private Connection conn() { return DBConnection.getInstance().getConnection(); }

    public List<Schedule> findAvailableByDoctorAndDate(int doctorId, String date) throws SQLException {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT * FROM schedules WHERE doctor_id=? AND slot_date=? AND is_booked=FALSE ORDER BY slot_time";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId); ps.setString(2, date);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapSchedule(rs));
            }
        }
        return list;
    }

    public List<Schedule> findByDoctorAndDate(int doctorId, String date) throws SQLException {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT * FROM schedules WHERE doctor_id=? AND slot_date=? ORDER BY slot_time";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId); ps.setString(2, date);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapSchedule(rs));
            }
        }
        return list;
    }

    public Schedule findById(int id) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("SELECT * FROM schedules WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapSchedule(rs);
            }
        }
        return null;
    }

    public int insert(int doctorId, String date, String time) throws SQLException {
        String sql = "INSERT INTO schedules (doctor_id, slot_date, slot_time, is_booked) VALUES (?,?,?,FALSE)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, doctorId); ps.setString(2, date); ps.setString(3, time);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public void markBooked(int scheduleId, boolean booked) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("UPDATE schedules SET is_booked=? WHERE id=?")) {
            ps.setBoolean(1, booked); ps.setInt(2, scheduleId);
            ps.executeUpdate();
        }
    }

    public int countAvailableSlots(int doctorId, String date) throws SQLException {
        String sql = "SELECT COUNT(*) FROM schedules WHERE doctor_id=? AND slot_date=? AND is_booked=FALSE";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId); ps.setString(2, date);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    public int countTotalSlots(int doctorId, String date) throws SQLException {
        String sql = "SELECT COUNT(*) FROM schedules WHERE doctor_id=? AND slot_date=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId); ps.setString(2, date);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    private Schedule mapSchedule(ResultSet rs) throws SQLException {
        Schedule s = new Schedule();
        s.setId(rs.getInt("id"));
        s.setDoctorId(rs.getInt("doctor_id"));
        s.setSlotDate(rs.getString("slot_date"));
        s.setSlotTime(rs.getString("slot_time"));
        s.setBooked(rs.getBoolean("is_booked"));
        return s;
    }
}
