package dao;

import model.User;
import util.DBConnection;

import java.sql.*;
import java.util.*;

public class UserDAO {
    private Connection conn() { return DBConnection.getInstance().getConnection(); }

    public User authenticate(String username, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapUser(rs);
            }
        }
        return null;
    }

    public int insert(User u) throws SQLException {
        String sql = "INSERT INTO users (username,password,role,full_name,email,phone) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getUsername()); ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole());     ps.setString(4, u.getFullName());
            ps.setString(5, u.getEmail());    ps.setString(6, u.getPhone());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public List<User> findAll() throws SQLException {
        List<User> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM users")) {
            while (rs.next()) list.add(mapUser(rs));
        }
        return list;
    }

    public boolean usernameExists(String username) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("SELECT id FROM users WHERE username=?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public void delete(int id) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM users WHERE id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {
        return new User(
            rs.getInt("id"), rs.getString("username"), rs.getString("password"),
            rs.getString("role"), rs.getString("full_name"),
            rs.getString("email"), rs.getString("phone")
        );
    }
}
