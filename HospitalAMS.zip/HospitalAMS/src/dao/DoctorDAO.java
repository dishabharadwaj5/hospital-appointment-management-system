package dao;

import model.Doctor;
import util.DBConnection;

import java.sql.*;
import java.util.*;

public class DoctorDAO {
    private Connection conn() { return DBConnection.getInstance().getConnection(); }

    public List<Doctor> findAll() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        String sql = "SELECT d.*, u.full_name, u.email, u.phone, " +
                     "(SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=d.id AND a.status='BOOKED') AS booked_slots " +
                     "FROM doctors d JOIN users u ON d.user_id=u.id";
        try (Statement st = conn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapDoctor(rs));
        }
        return list;
    }

    public Doctor findById(int id) throws SQLException {
        String sql = "SELECT d.*, u.full_name, u.email, u.phone, " +
                     "(SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=d.id AND a.status='BOOKED') AS booked_slots " +
                     "FROM doctors d JOIN users u ON d.user_id=u.id WHERE d.id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapDoctor(rs);
            }
        }
        return null;
    }

    public Doctor findByUserId(int userId) throws SQLException {
        String sql = "SELECT d.*, u.full_name, u.email, u.phone, " +
                     "(SELECT COUNT(*) FROM appointments a WHERE a.doctor_id=d.id AND a.status='BOOKED') AS booked_slots " +
                     "FROM doctors d JOIN users u ON d.user_id=u.id WHERE d.user_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapDoctor(rs);
            }
        }
        return null;
    }

    public int insert(int userId, String specialization, String qualification, int totalSlots) throws SQLException {
        String sql = "INSERT INTO doctors (user_id, specialization, qualification, total_slots) VALUES (?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId); ps.setString(2, specialization);
            ps.setString(3, qualification); ps.setInt(4, totalSlots);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public void update(int id, String specialization, String qualification, int totalSlots) throws SQLException {
        String sql = "UPDATE doctors SET specialization=?, qualification=?, total_slots=? WHERE id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, specialization); ps.setString(2, qualification);
            ps.setInt(3, totalSlots);        ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM doctors WHERE id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
        }
    }

    public List<Map<String, Object>> getDoctorAppointmentCounts() throws SQLException {
        List<Map<String, Object>> result = new ArrayList<>();
        String sql = "SELECT u.full_name, d.specialization, d.total_slots, " +
                     "COUNT(CASE WHEN a.status='BOOKED' THEN 1 END) AS booked, " +
                     "COUNT(CASE WHEN a.status='COMPLETED' THEN 1 END) AS completed, " +
                     "COUNT(CASE WHEN a.status='CANCELLED' THEN 1 END) AS cancelled " +
                     "FROM doctors d JOIN users u ON d.user_id=u.id " +
                     "LEFT JOIN appointments a ON a.doctor_id=d.id " +
                     "GROUP BY d.id, u.full_name, d.specialization, d.total_slots";
        try (Statement st = conn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("doctorName", rs.getString("full_name"));
                row.put("specialization", rs.getString("specialization"));
                row.put("totalSlots", rs.getInt("total_slots"));
                row.put("booked", rs.getInt("booked"));
                row.put("completed", rs.getInt("completed"));
                row.put("cancelled", rs.getInt("cancelled"));
                result.add(row);
            }
        }
        return result;
    }

    private Doctor mapDoctor(ResultSet rs) throws SQLException {
        Doctor d = new Doctor();
        d.setId(rs.getInt("id"));
        d.setUserId(rs.getInt("user_id"));
        d.setFullName(rs.getString("full_name"));
        d.setSpecialization(rs.getString("specialization"));
        d.setQualification(rs.getString("qualification"));
        d.setTotalSlots(rs.getInt("total_slots"));
        d.setBookedSlots(rs.getInt("booked_slots"));
        return d;
    }
}
