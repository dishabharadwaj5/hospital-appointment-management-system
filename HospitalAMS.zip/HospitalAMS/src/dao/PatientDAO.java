package dao;

import model.Patient;
import util.DBConnection;

import java.sql.*;
import java.util.*;

public class PatientDAO {
    private Connection conn() { return DBConnection.getInstance().getConnection(); }

    public List<Patient> findAll() throws SQLException {
        List<Patient> list = new ArrayList<>();
        String sql = "SELECT p.*, u.full_name, u.email, u.phone FROM patients p JOIN users u ON p.user_id=u.id";
        try (Statement st = conn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapPatient(rs));
        }
        return list;
    }

    public Patient findById(int id) throws SQLException {
        String sql = "SELECT p.*, u.full_name, u.email, u.phone FROM patients p JOIN users u ON p.user_id=u.id WHERE p.id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapPatient(rs);
            }
        }
        return null;
    }

    public Patient findByUserId(int userId) throws SQLException {
        String sql = "SELECT p.*, u.full_name, u.email, u.phone FROM patients p JOIN users u ON p.user_id=u.id WHERE p.user_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapPatient(rs);
            }
        }
        return null;
    }

    public int insert(int userId, int age, String gender, String address) throws SQLException {
        String sql = "INSERT INTO patients (user_id, age, gender, address) VALUES (?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId); ps.setInt(2, age);
            ps.setString(3, gender); ps.setString(4, address);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public void update(int id, int age, String gender, String address) throws SQLException {
        String sql = "UPDATE patients SET age=?, gender=?, address=? WHERE id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, age); ps.setString(2, gender);
            ps.setString(3, address); ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM patients WHERE id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
        }
    }

    private Patient mapPatient(ResultSet rs) throws SQLException {
        Patient p = new Patient();
        p.setId(rs.getInt("id"));
        p.setUserId(rs.getInt("user_id"));
        p.setFullName(rs.getString("full_name"));
        p.setAge(rs.getInt("age"));
        p.setGender(rs.getString("gender"));
        p.setAddress(rs.getString("address"));
        p.setEmail(rs.getString("email"));
        p.setPhone(rs.getString("phone"));
        return p;
    }
}
