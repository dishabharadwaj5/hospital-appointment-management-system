package dao;

import model.Appointment;
import util.DBConnection;

import java.sql.*;
import java.util.*;

public class AppointmentDAO {
    private Connection conn() { return DBConnection.getInstance().getConnection(); }

    public int insert(Appointment a) throws SQLException {
        String sql = "INSERT INTO appointments (patient_id,doctor_id,schedule_id,appointment_date,appointment_time,status,notes) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getPatientId());    ps.setInt(2, a.getDoctorId());
            ps.setInt(3, a.getScheduleId());   ps.setString(4, a.getAppointmentDate());
            ps.setString(5, a.getAppointmentTime()); ps.setString(6, "BOOKED");
            ps.setString(7, a.getNotes());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public List<Appointment> findAll() throws SQLException {
        return query("SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name, d.specialization " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "ORDER BY a.appointment_date DESC, a.appointment_time");
    }

    public List<Appointment> findByPatientId(int patientId) throws SQLException {
        String sql = "SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name, d.specialization " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "WHERE a.patient_id=? ORDER BY a.appointment_date DESC";
        return queryWithParam(sql, patientId);
    }

    public List<Appointment> findByDoctorId(int doctorId) throws SQLException {
        String sql = "SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name, d.specialization " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "WHERE a.doctor_id=? ORDER BY a.appointment_date DESC";
        return queryWithParam(sql, doctorId);
    }

    public List<Appointment> findByDate(String date) throws SQLException {
        String sql = "SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name, d.specialization " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "WHERE a.appointment_date=? ORDER BY a.appointment_time";
        List<Appointment> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, date);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapAppointment(rs));
            }
        }
        return list;
    }

    public Appointment findById(int id) throws SQLException {
        String sql = "SELECT a.*, up.full_name AS patient_name, ud.full_name AS doctor_name, d.specialization " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "WHERE a.id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapAppointment(rs);
            }
        }
        return null;
    }

    public void updateStatus(int id, String status) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("UPDATE appointments SET status=? WHERE id=?")) {
            ps.setString(1, status); ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    public Map<String, Object> getDailySummary(String date) throws SQLException {
        Map<String, Object> summary = new LinkedHashMap<>();
        String sql = "SELECT COUNT(*) AS total, " +
                     "SUM(CASE WHEN status='BOOKED' THEN 1 ELSE 0 END) AS booked, " +
                     "SUM(CASE WHEN status='COMPLETED' THEN 1 ELSE 0 END) AS completed, " +
                     "SUM(CASE WHEN status='CANCELLED' THEN 1 ELSE 0 END) AS cancelled " +
                     "FROM appointments WHERE appointment_date=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, date);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    summary.put("date", date);
                    summary.put("total", rs.getInt("total"));
                    summary.put("booked", rs.getInt("booked"));
                    summary.put("completed", rs.getInt("completed"));
                    summary.put("cancelled", rs.getInt("cancelled"));
                }
            }
        }
        // remaining slots across all doctors for the date
        String slotSql = "SELECT COUNT(*) AS remaining FROM schedules WHERE slot_date=? AND is_booked=FALSE";
        try (PreparedStatement ps = conn().prepareStatement(slotSql)) {
            ps.setString(1, date);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) summary.put("remainingSlots", rs.getInt("remaining"));
            }
        }
        return summary;
    }

    public List<Map<String, Object>> getReportData() throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT a.id, up.full_name AS patient, ud.full_name AS doctor, " +
                     "d.specialization, a.appointment_date AS date, a.appointment_time AS time, a.status " +
                     "FROM appointments a " +
                     "JOIN patients p ON a.patient_id=p.id JOIN users up ON p.user_id=up.id " +
                     "JOIN doctors d ON a.doctor_id=d.id JOIN users ud ON d.user_id=ud.id " +
                     "ORDER BY a.appointment_date DESC";
        try (Statement st = conn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("ID", rs.getInt("id"));
                row.put("Patient", rs.getString("patient"));
                row.put("Doctor", rs.getString("doctor"));
                row.put("Specialization", rs.getString("specialization"));
                row.put("Date", rs.getString("date"));
                row.put("Time", rs.getString("time"));
                row.put("Status", rs.getString("status"));
                list.add(row);
            }
        }
        return list;
    }

    private List<Appointment> query(String sql) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (Statement st = conn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapAppointment(rs));
        }
        return list;
    }

    private List<Appointment> queryWithParam(String sql, int param) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapAppointment(rs));
            }
        }
        return list;
    }

    private Appointment mapAppointment(ResultSet rs) throws SQLException {
        Appointment a = new Appointment();
        a.setId(rs.getInt("id"));
        a.setPatientId(rs.getInt("patient_id"));
        a.setDoctorId(rs.getInt("doctor_id"));
        a.setScheduleId(rs.getInt("schedule_id"));
        a.setAppointmentDate(rs.getString("appointment_date"));
        a.setAppointmentTime(rs.getString("appointment_time"));
        a.setStatus(rs.getString("status"));
        a.setNotes(rs.getString("notes"));
        a.setPatientName(rs.getString("patient_name"));
        a.setDoctorName(rs.getString("doctor_name"));
        a.setSpecialization(rs.getString("specialization"));
        return a;
    }
}
