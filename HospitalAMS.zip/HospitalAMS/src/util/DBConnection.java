package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton pattern for DB connection management.
 * Ensures a single shared connection to MySQL.
 */
public class DBConnection {
    private static DBConnection instance;
    private Connection connection;

    // ── Change these to match your local MySQL setup ──
    private static final String URL      = "jdbc:mysql://localhost:3306/hospital_ams?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER     = "root";
    private static final String PASSWORD = "root";   // ← update if needed

    private DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("[DB] Connected to hospital_ams successfully.");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("[DB] MySQL JDBC Driver not found. Place mysql-connector-j-*.jar in lib/", e);
        } catch (SQLException e) {
            throw new RuntimeException("[DB] Connection failed: " + e.getMessage(), e);
        }
    }

    public static synchronized DBConnection getInstance() {
        if (instance == null || isConnectionClosed()) {
            instance = new DBConnection();
        }
        return instance;
    }

    private static boolean isConnectionClosed() {
        try {
            return instance.connection == null || instance.connection.isClosed();
        } catch (SQLException e) {
            return true;
        }
    }

    public Connection getConnection() {
        return connection;
    }
}
