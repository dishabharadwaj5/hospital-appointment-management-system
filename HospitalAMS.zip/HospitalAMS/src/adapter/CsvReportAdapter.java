package adapter;

import java.util.List;
import java.util.Map;

/**
 * STRUCTURAL PATTERN: Adapter
 * Adapts RawCsvGenerator to the ReportFormatter interface.
 */
public class CsvReportAdapter implements ReportFormatter {
    private final RawCsvGenerator adaptee = new RawCsvGenerator();

    @Override
    public String format(List<Map<String, Object>> data) {
        return adaptee.generateCsv(data);
    }

    @Override
    public String getContentType() {
        return "text/csv";
    }

    @Override
    public String getFileExtension() {
        return "csv";
    }
}
