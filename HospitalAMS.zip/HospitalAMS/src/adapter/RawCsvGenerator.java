package adapter;

import java.util.List;
import java.util.Map;

/**
 * Adaptee: raw CSV generator (legacy format).
 */
public class RawCsvGenerator {
    public String generateCsv(List<Map<String, Object>> rows) {
        if (rows == null || rows.isEmpty()) return "No data available\n";
        StringBuilder sb = new StringBuilder();
        // Headers
        sb.append(String.join(",", rows.get(0).keySet())).append("\n");
        for (Map<String, Object> row : rows) {
            boolean first = true;
            for (Object val : row.values()) {
                if (!first) sb.append(",");
                String s = val == null ? "" : val.toString();
                if (s.contains(",") || s.contains("\"")) {
                    s = "\"" + s.replace("\"", "\"\"") + "\"";
                }
                sb.append(s);
                first = false;
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
