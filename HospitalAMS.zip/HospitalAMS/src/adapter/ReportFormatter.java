package adapter;

import java.util.List;
import java.util.Map;

/**
 * Target interface for report output.
 */
public interface ReportFormatter {
    String format(List<Map<String, Object>> data);
    String getContentType();
    String getFileExtension();
}
