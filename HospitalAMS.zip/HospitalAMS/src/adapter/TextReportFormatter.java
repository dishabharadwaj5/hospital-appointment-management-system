package adapter;

import java.util.List;
import java.util.Map;

/**
 * Concrete ReportFormatter for plain-text output.
 */
public class TextReportFormatter implements ReportFormatter {

    @Override
    public String format(List<Map<String, Object>> data) {
        if (data == null || data.isEmpty()) return "No data available.\n";
        StringBuilder sb = new StringBuilder();
        sb.append("=== HOSPITAL APPOINTMENT MANAGEMENT SYSTEM REPORT ===\n\n");
        for (Map<String, Object> row : data) {
            for (Map.Entry<String, Object> e : row.entrySet()) {
                sb.append(String.format("%-20s: %s\n", e.getKey(), e.getValue()));
            }
            sb.append("-".repeat(45)).append("\n");
        }
        sb.append("\nTotal records: ").append(data.size()).append("\n");
        return sb.toString();
    }

    @Override
    public String getContentType() { return "text/plain"; }

    @Override
    public String getFileExtension() { return "txt"; }
}
