package factory;

import model.User;

/**
 * CREATIONAL PATTERN: Factory Method
 * Creates User objects configured for each role.
 */
public class UserFactory {

    public static User createUser(String role, String username, String password,
                                   String fullName, String email, String phone) {
        if (role == null) throw new IllegalArgumentException("Role cannot be null");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);

        switch (role.toUpperCase()) {
            case "ADMIN":
                user.setRole("ADMIN");
                break;
            case "DOCTOR":
                user.setRole("DOCTOR");
                break;
            case "PATIENT":
                user.setRole("PATIENT");
                break;
            default:
                throw new IllegalArgumentException("Unknown role: " + role);
        }
        return user;
    }
}
